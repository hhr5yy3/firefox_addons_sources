Third Party Libraries:
======================

Location /popup/tableview/lib
-------------------------------------------
jQuery core 3.6.0 - minified
https://code.jquery.com/jquery-3.6.0.min.js

Reference (not part of distribution): jQuery core 3.6.0 - human-readable source code
https://code.jquery.com/jquery-3.6.0.js

jQuery plugin DataTables 1.10.21 - minified
https://github.com/DataTables/DataTables/blob/1.10.21/media/js/jquery.dataTables.min.js

Reference (not part of distribution): jQuery plugin DataTables 1.10.21 - human-readable source code
https://github.com/DataTables/DataTables/blob/1.10.21/media/js/jquery.dataTables.js

DataTable extension Responsive 2.2.6
https://github.com/DataTables/Responsive/blob/2.2.6/js/dataTables.responsive.js

DataTable extension Select 1.3.1
https://github.com/DataTables/Select/blob/1.3.1/js/dataTables.select.js

DataTable extension Buttons 1.6.5
https://github.com/DataTables/Buttons/blob/1.6.5/js/buttons.colVis.js
https://github.com/DataTables/Buttons/blob/1.6.5/js/dataTables.buttons.js

jquery plugin custom scrollbar 3.1.5
https://github.com/malihu/malihu-custom-scrollbar-plugin/blob/3.1.5/jquery.mCustomScrollbar.js

jQuery plugin Mousewheel 3.1.13
https://github.com/jquery/jquery-mousewheel/blob/3.1.13/jquery.mousewheel.js


Location /popup/entryview/renderjs
----------------------------------------------------
marked 2.0.2 (markdown parser and compiler)
https://github.com/markedjs/marked/blob/v2.0.2/lib/marked.js


Location /common
---------------------------
DOMPurify 2.2.7
https://github.com/cure53/DOMPurify/blob/2.2.7/dist/purify.js