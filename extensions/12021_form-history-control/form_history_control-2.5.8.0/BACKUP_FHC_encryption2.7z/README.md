# Form History Control II

This is an adaptation of the original version making it suitable to work with web-extensions and e10s.

## Homepage
Homepage is now on github pages: [Form History Control](https://stephanmahieu.github.io/fhc-home)

The blog is still maintained: https://formhistory.blogspot.com/