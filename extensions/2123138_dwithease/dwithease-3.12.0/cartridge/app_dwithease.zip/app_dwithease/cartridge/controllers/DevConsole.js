/* eslint-disable prefer-template */
/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
/* globals dw */

var ArrayList = require('dw/util/ArrayList');
var ISML = require('dw/template/ISML');

var models = require('*/cartridge/scripts/models');

function execute() {
    var body = request.httpParameterMap.requestBodyAsString;
    var showGettersAndSetter = request.httpHeaders.get('x-getters-setters');
    var showAllProperties = request.httpHeaders.get('x-all-properties');

    var outputPreferences = {
        showGettersAndSetter: showGettersAndSetter,
        showAllProperties: showAllProperties
    };

    var object;
    var objectJson;

    try {
        var result = new Function(body);

        object = result.call(null);

        var objectResult = models.serialize(object, outputPreferences);

        objectJson = JSON.stringify(objectResult);

        response.setContentType('application/json');
        response.writer.print(objectJson);
    } catch (e) {
        response.setContentType('application/json');
        response.writer.print(e);
    }
}

function executePreview() {
    var body = request.httpParameterMap.requestBodyAsString;
    var object;

    try {
        var result = new Function(body);

        object = result.call(null);

        ISML.renderTemplate('custom/templateTest', object);
    } catch (e) {
        var error = e;

        ISML.renderTemplate('generic/result', {
            ObjectDump: e,
        });
    }
}

execute.public = true;
executePreview.public = true;

module.exports = {
    Execute: execute,
    ExecutePreview: executePreview
}
