var gettersAndSetters = [/get/g, /set/g, /is/g];
var MAX_DEPTH_LEVEL = 3;
var propertiesToSkip = [
    "constructor",
    "class",
    "describe",
    "equals",
    "getClass",
    "getConstructor",
    "hasOwnProperty",
    "hashCode",
    "isPrototypeOf",
    "notify",
    "notifyAll",
    "propertyIsEnumerable",
    "toJSON",
    "toLocaleString",
    "toString",
    "valueOf",
    "wait",
    'privacy',
];

var depth_level = 1;

function isPrimitive(property) {
    return (property !== Object(property));
};

function isFunction(property) {
    return typeof property === 'function'
};

function isGetterOrSetter(apiObject, propertyKey) {
    var isGetterOrSetter = false;

    for (var key in gettersAndSetters) {
        const hasMatch = propertyKey.match(gettersAndSetters[key]);

        if (hasMatch) {
            const propertyName = propertyKey.replace(hasMatch, '');
            const lowerCasedPropertyName = propertyName.charAt(0).toLowerCase() + propertyName.slice(1);

            if (lowerCasedPropertyName in apiObject) {
                isGetterOrSetter = true;

                break;
            }
        }
    };

    return isGetterOrSetter;
}

var models = [
    {
        instance: dw.catalog.VariationGroup,
        model: function () {
            return ['ID', 'brand', 'name', 'masterProduct', 'image', 'custom', 'longDescription'];
        }
    },
    {
        instance: dw.catalog.Product,
        model: function () {
            return ['ID', 'name', 'longDescription', 'master', 'pageTitle', 'image', 'brand'];
        }
    },
    {
        instance: dw.catalog.Variant,
        model: function () {
            return ['ID', 'name', 'longDescription', 'masterProduct  ', 'pageTitle', 'image', 'brand'];
        }
    },
    {
        instance: dw.catalog.Category,
        model: function() {
            return ['ID', 'displayName', 'online', 'description'];
        }
    },
    {
        instance: dw.catalog.CategoryAssignment,
        model: function() {
            return ['name', 'shortDescription', 'longDescription', 'product'];
        }
    },
    {
        instance: dw.catalog.ProductAttributeModel,
        model: function() {
            return ['attributeGroups'];
        }
    },
    {
        instance: dw.catalog.ProductInventoryRecord,
        model: function() {
            return ['allocation', 'ATS', 'inStockDate', 'onOrder'];
        }
    },
    {
        instance: dw.catalog.Recommendation,
        model: function() {
            return ['name', 'calloutMsg', 'recommendationType', 'shortDescription', 'sourceItemID'];
        }
    },
    {
        instance: dw.catalog.ProductAvailabilityModel,
        model: function() {
            return ['availability', 'inStock', 'availabilityStatus', 'orderable', 'timeToOutOfStock'];
        }
    },
    {
        instance: dw.catalog.ProductOptionModel,
        model: function() {
            return ['ID', 'name', 'content', 'property', 'title'];
        }
    },
    {
        instance: dw.catalog.ProductActiveData,
        model: function() {
            return ['availableDate', 'costPrice', 'impressionsDay', 'avgSalesPriceYear'];
        }
    },
    {
        instance: dw.catalog.ProductPriceModel,
        model: function() {
            return ['price', 'minPrice', 'maxPrice', 'priceInfo'];
        }
    },
    {
        instance: dw.catalog.ProductPriceInfo,
        model: function() {
            return ['price', 'priceBook', 'percentage', 'priceInfo', 'onlineTo', 'onlineFrom'];
        }
    },
    {
        instance: dw.catalog.ProductPriceTable,
        model: function() {
            return ['quantities'];
        }
    },
    {
        instance: dw.catalog.SortingRule,
        model: function() {
            return ['ID', 'getID'];
        }
    },
    {
        instance: dw.catalog.ProductVariationModel,
        model: function() {
            return ['selectedVariant', 'productVariationAttributes', 'master', 'defaultVariant', 'variants', 'variationGroups'];
        }
    },
    {
        instance: dw.web.PageMetaTag,
        model: function() {
            return ['ID', 'name'];
        }
    },
    {
        instance: dw.content.Folder,
        model: function() {
            return ['ID', 'displayName', 'description', 'content', 'online', 'pageTitle'];
        }
    },
    {
        instance: dw.customer.Customer,
        model: function() {
            return ['ID', 'addressBook', 'profile', 'registered', 'addressBook'];
        }
    },
    {
        instance: dw.customer.AddressBook,
        model: function() {
            return ['addresses', 'removeAddress', 'createAddress', 'preferredAddress'];
        }
    },
    {
        instance: dw.customer.Profile,
        model: function() {
            return ['firstName', 'lastName', 'email', 'birthday', 'title'];
        }
    },
    {
        instance: dw.customer.OrderHistory,
        model: function() {
            return ['orderCount', 'getOrderCount'];
        }
    },
    {
        instance: dw.customer.Wallet,
        model: function() {
            return ['paymentInstruments', 'getPaymentInstruments'];
        }
    },
    {
        instance: dw.customer.CustomerAddress,
        model: function() {
            return ['ID', 'title', 'firstName', 'lastName', 'address1', 'address2', 'postalCode', 'city'];
        }
    },
    {
        instance: dw.customer.Credentials,
        model: function() {
            return ['login', 'enabled', 'passwordAnswer', 'passwordQuestion', 'locked'];
        }
    },
    {
        instance: dw.customer.CustomerGroup,
        model: function() {
            return ['ID', 'description', 'ruleBased'];
        }
    },
    {
        instance: dw.order.OrderAddress,
        model: function() {
            return ['firstName', 'secondName', 'title', 'city', 'address1', 'address2', 'postalCode'];
        }
    },
    {
        instance: dw.order.Order,
        model: function() {
            return ['orderNo', 'paymentStatus', 'shippingStatus', 'status', 'currentOrder', 'createdBy', 'invoiceNo', 'paymentInstrument'];
        }
    },
    {
        instance: dw.order.Shipment,
        model: function() {
            return ['ID', 'shipmentNo', 'productLineItems', 'shippingAddress', 'shippingMethod', 'shippingStatus', 'totalNetPrice', 'totalGrossPrice'];
        }
    },
    {
        instance: dw.order.ShippingMethod,
        model: function() {
            return ['ID', 'displayName', 'baseMethod', 'online', 'defaultMethod', 'currencyCode'];
        }
    },
    {
        instance: dw.order.ShippingLineItem,
        model: function() {
            return ['ID', 'orderItem', 'shippingPriceAdjustments', 'adjustedTax', 'adjustedPrice'];
        }
    },
    {
        instance: dw.order.OrderPaymentInstrument,
        model: function() {
            return ['capturedAmount', 'paymentTransaction', 'bankAccountNumber', 'creditCardNumber', 'refundedAmount'];
        }
    },
    {
        instance: dw.order.PaymentTransaction,
        model: function() {
            return ['transactionID', 'paymentProcessor', 'paymentInstrument', 'amount', 'type'];
        }
    },
    {
        instance: dw.order.PaymentProcessor,
        model: function() {
            return ['ID'];
        }
    },
    {
        instance: dw.order.PaymentMethod,
        model: function() {
            return ['ID', 'name', 'paymentProcessor', 'active', 'description', 'image', 'activePaymentCards'];
        }
    },
    {
        instance: dw.campaign.Campaign,
        model: function() {
            return ['ID', 'promotions', 'description', 'active', 'startDate', 'endDate'];
        }
    },
    {
        instance: dw.campaign.Promotion,
        model: function() {
            return ['ID', 'name', 'calloutMsg', 'details', 'description', 'active', 'promotionClass', 'campaign'];
        }
    },
    {
        instance: dw.campaign.Coupon,
        model: function() {
            return ['ID', 'codePrefix', 'promotions', 'type', 'enabled', 'redemptionLimitPerCode', 'redemptionLimitPerCustomer'];
        }
    },
    {
        instance: dw.value.Quantity,
        model: function() {
            return ['unit', 'value', 'decimalValue', 'available'];
        }
    },
    {
        instance: dw.object.CustomObject,
        model: function() {
            return ['custom', 'type'];
        }
    },
    {
        instance: dw.system.Site,
        model: function() {
            return ['ID', 'name', 'defaultLocale', 'defaultCurrency', 'current', 'status'];
        }
    },
    {
        instance: dw.system.SitePreferences,
        model: function() {
            return ['sourceCodeURLParameterName'];
        }
    },
    {
        instance: dw.util.Collection,
        model: function(collection) {
            var iterator = collection.iterator();

            if (iterator.hasNext()) {
                var nextValue = iterator.next();

                return findModel(nextValue);
            }
            return null;
        },
    },
    {
        instance: dw.util.SeekableIterator,
        model: function(seekableIterator) {
            var iterator = seekableIterator.iterator();

            if (iterator.hasNext()) {
                var nextValue = iterator.next();

                return findModel(nextValue);
            }
            return null;
        },
    },
    {
        instance: dw.util.ArrayList,
        model: function(array) {
            if (!array.isEmpty()) {
                return findModel(array.get(0));
            }
            return null;
        },
    },
];

function findModel(apiObject) {
    for (var i = 0; i < models.length; i++) {
        if (apiObject instanceof models[i].instance) {
            return models[i].model(apiObject);
        }
    }

    return apiObject.toString();
}

function getCustomAttributes(apiObject) {
    var isSearchRefinementDefinition = apiObject instanceof dw.catalog.SearchRefinementDefinition;
    var isExtensibleObject = apiObject instanceof dw.object.ExtensibleObject;
    isExtensibleObject = isExtensibleObject || (apiObject == session);

    var customAttributes = {};

    if (!isSearchRefinementDefinition && isExtensibleObject && ('custom' in apiObject)) {
        for (var key in apiObject.custom) {
            customAttributes[key] = apiObject.custom[key];
        }
    }

    return customAttributes;
}

function serialize(apiObject, outputPreferences) {
    var propertyNames = [];
    var propertyValues = [];

    var result = {};
    var sortedObject = {};

    for (var key in apiObject) {
        if (apiObject instanceof dw.util.SeekableIterator && apiObject.hasNext()) {
            try {
                var objectValue = apiObject.next();
            } catch (e) {
                var objectValue = 'not accessible'
            }
        } else {
            try {
                var objectValue = apiObject[key];
            } catch (e) {
                var objectValue = 'not accessible'
            }
        }

        if (propertiesToSkip.indexOf(key) === -1) {
            var stringValue = objectValue && objectValue.toString();

            propertyNames.push(key);

            if (isFunction(objectValue)) {
                if (outputPreferences.showGettersAndSetter !== 'true' && isGetterOrSetter(apiObject, key)) {
                    propertyNames.pop();
                } else {
                    result[key] = '[Function]';
                }
            } else if (!isPrimitive(objectValue)) {
                if (depth_level < MAX_DEPTH_LEVEL) {
                    var attributes = findModel(objectValue);
                    depth_level++;

                    if (attributes instanceof Array && attributes.length > 0) {
                        if (outputPreferences.showAllProperties === 'true') {
                            result[key] = serialize(objectValue, outputPreferences);
                        } else {
                            if (objectValue instanceof dw.util.Collection) {
                                var iterator = objectValue.iterator();
                                result[key] = [];

                                while (iterator.hasNext()) {
                                    var item = iterator.next();
                                    var shortObject = {};

                                    attributes.forEach(function(attribute) {
                                        if (attribute in item) {
                                            shortObject[attribute] = item[attribute];
                                        }
                                    });

                                    result[key].push(serialize(shortObject, outputPreferences));
                                }
                            } else {
                                var shortObject = {};

                                attributes.forEach(function(attribute) {
                                    if (attribute in objectValue) {
                                        shortObject[attribute] = objectValue[attribute];
                                    }
                                });

                                result[key] = serialize(shortObject, outputPreferences);
                            }
                        }
                    } else {
                        if (objectValue instanceof dw.util.Collection) {
                            result[key] = [];
                        } else if (key === 'custom') {
                            try {
                                result[key] = getCustomAttributes(apiObject);
                            } catch (error) {
                                result[key] = '';
                            }
                        } else {
                            result[key] = stringValue;
                        }
                    }

                    depth_level--;
                } else {
                    result[key] = stringValue;
                }
            } else {
                result[key] = objectValue;
            }
        }
    }

    propertyNames.sort(function(a, b) {
        try {
            if (typeof apiObject[a] === 'function') {
                if (typeof apiObject[b] === 'function') {
                    return a.localeCompare(b);
                }

                return 1;
            }

            if (typeof apiObject[b] === 'function') {
                return -1;
            }

            return a.localeCompare(b);
        } catch (error) {
            return -1;
        }
    });

    for (let i = 0; i < propertyNames.length; i++) {
        sortedObject[propertyNames[i]] = result[propertyNames[i]];
    }

    return sortedObject;
}

module.exports = {
    serialize: serialize
};
