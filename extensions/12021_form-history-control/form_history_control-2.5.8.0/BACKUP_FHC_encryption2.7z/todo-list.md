# TODO list Formhistory Control II

## Tasks

- Create (python) scripts for publishing zip
  - remove description labels from messages.json
  - remove polyfill scripts for mozilla zip
- shortcut keys / configurable key-bindings
- cleanup
     - options (max entries, oldest, protect-flag?)
- when copying to clipboard, if data contains html then ask (dialog) if copy text or html
- Advanced/Expert filter options (regex)
- in search filter, add X clear filter icon
- auto resize popups (preferences)
- restore field(a) with original values
- extra properties entry: protect-from-cleanup, favorite?
- remember form positions and size
- export: option to export only selected items
- menu: use key(s) to open or invoke menuitems
- buttons: use key(s) to open or invoke menuitems


## Home pages

- Known issues
  - add facebook restore issue
  - extensions not working on mozilla.org